# -*- coding: utf-8 -*-
from flask import Flask
from flask_restful import Resource, Api, reqparse

app = Flask(__name__)
api = Api(app)

parser = reqparse.RequestParser()

class Quotes(Resource):
    def post(self):
        parser.add_argument('quote', type=str)
        args = parser.parse_args()

        return {
            'status': True,
            'quote': '{} added. Good'.format(args['quote'])
        }

api.add_resource(Quotes, '/')

if __name__ == '__main__':
    app.run(debug=True)