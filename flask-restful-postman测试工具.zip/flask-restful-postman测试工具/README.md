# 步骤
```bash
pip install flask-restful

python main.py
```
1. 打开 postman
2. 点击 **import** 按钮
3. 选择 **Import File** 选项卡
4. 点击 **Choose Files** 按钮
5. 选择 文件 `restful-demo-01.postman_collection.json`


---

# Flask-RESTful
> 优质博客和官方文档，需要认真看

* [Building Basic RESTful API with Flask-RESTful](https://dev.to/aligoren/building-basic-restful-api-with-flask-restful-57oh)
* [使用 Flask 设计 RESTful APIs](http://www.pythondoc.com/flask-restful/index.html)
* [Flask-RESTful-中文文档](http://www.pythondoc.com/Flask-RESTful/index.html)
* [Flask-RESTful-Eng-Doc](https://flask-restful.readthedocs.io/en/latest/)


# Flask-RESTful-博客
> 有时间就看，难度小，加入了博客作者自己的理解

* [Flask 扩展系列之 Flask-RESTful](https://segmentfault.com/a/1190000012692984)


# curl
> curl 是Linux上的一个命令行工具，用户发送HTTP请求

* [Convert curl syntax to Python, Node.js, R, PHP, Go](https://curl.trillworks.com/)
* [GitHub: NickCarneiro/curlconverter](https://github.com/NickCarneiro/curlconverter/)