bs8 = 'abc中de'.encode('utf-8')

bsk = 'abc中de'.encode('gbk')

bs2 = 'abc中de'.encode('gb2312')

bsk.decode('gbk', errors='ignore')

bsk.decode('gb2312', errors='ignore')

bsk.decode('utf-8', errors='ignore')

try:
    bsk.decode('utf-8')
except:
    print('编码转换有误')