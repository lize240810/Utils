# -*- coding: utf-8 -*-
# 模块倒入
try:
    import chardet
except ImportError:
    # 如果导入第三方库出错，一般是未安装
    # 调用pip安装
    import os
    os.system('pip install chardet')
    # 安装完成后重新导入
    import chardet

# 要判断编码的内容
bys = b'hehe'
# 判断编码
det = chardet.detect(bys)
# 获取编码
encoding = None
# 可能检测失败，需要判断
if isinstance(det, dict) and 'encoding' in det:
    encoding = det['encoding']
# 如果获取到了编码
if bool(encoding):
    # TODO：得到编码后做的事，以下是示例
    # 就算正确得到了编码，也要防止存在不可解码的字符
    # 所以需要设置errors参数值为'ignore'或'replace'，一般用前者
    str_obj = bys.decode(encoding, errors='ignore')
    print(str_obj)
    # TODO: 对字符串操作
    pass
else:
    print('编码检测失败，请手动处理')